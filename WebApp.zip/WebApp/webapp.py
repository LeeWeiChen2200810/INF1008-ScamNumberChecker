from flask import Flask, render_template, request, redirect
import re
import hashlib
import json
import csv
import os
import phonenumbers
import time
app = Flask(__name__)

class Node:
    def __init__(self, question):
        self.question = question
        self.next = None

# Load questions from JSON file
def loadQuestions():
    try:
        with open('../Data/questions.json', 'r') as file:
            questions_data = json.load(file)
        return questions_data
    except FileNotFoundError:
        print("Error: The questions JSON file was not found.")
        return []
    except json.JSONDecodeError:
        print("Error: Failed to parse the questions JSON file.")
        return []

# Load keywords from CSV file
def load_keywords_from_csv():
    keywords_dict = {}
    with open('../Data/keyword_set.csv', newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row:
                keyword = row[0]
                keywords_dict[keyword] = True
    return keywords_dict

def binary_load_scam_numbers_from_csv():
    scam_numbers = []
    with open('../Data/numbers.csv', newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row:
                scam_numbers.append(row[0])
    return scam_numbers  # Sort the list to enable binary search

def load_scam_numbers_from_csv():
    scam_numbers = {}
    with open('../Data/numbers.csv', newline='') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            if row and len(row) == 2:
                phone_number, country = row
                scam_numbers[phone_number] = country
    return scam_numbers

# Red-Black Tree Node class definition
class RBNode:
    # Constructor to initialize a new node with the given keyword
    def __init__(self, keyword):
        self.keyword = keyword
        self.left = None
        self.right = None
        self.color = "red"  # All new nodes are initially colored red
        self.parent = None  # Parent attribute to track the parent node

# Perform a left rotation on the given pivot node in the Red-Black Tree.
def rotate_left(pivot):
    new_pivot = pivot.right
    pivot.right = new_pivot.left
    if new_pivot.left:
        new_pivot.left.parent = pivot
    new_pivot.left = pivot
    new_pivot.parent = pivot.parent
    pivot.parent = new_pivot
    return new_pivot

# Perform a right rotation on the given pivot node in the Red-Black Tree.
def rotate_right(pivot):
    new_pivot = pivot.left
    pivot.left = new_pivot.right
    if new_pivot.right:
        new_pivot.right.parent = pivot
    new_pivot.right = pivot
    new_pivot.parent = pivot.parent
    pivot.parent = new_pivot
    return new_pivot

#Fix the Red-Black Tree properties after inserting a new node.
def fix_insert(node):
    # Case 1: If the current node is the root, color it black
    if node.parent is None:
        node.color = "black"
        return node

    # Case 2: If the parent node is black, the tree is still valid
    if node.parent.color == "black":
        return node

    # Get the grandparent and uncle nodes
    grandparent = node.parent.parent
    uncle = grandparent.left if node.parent == grandparent.right else grandparent.right

    # Case 3: If the parent and uncle are red, recolor the parent, uncle, and grandparent
    if uncle and uncle.color == "red":
        node.parent.color = "black"
        uncle.color = "black"
        grandparent.color = "red"
        return fix_insert(grandparent)

    # Case 4: If the parent is red, but the uncle is black or NULL
    if node.parent == grandparent.left:
        if node == node.parent.right:
            # Left-right case, perform left rotation on parent
            node = rotate_left(node.parent)
            node = node.left
        # Left-left case, perform right rotation on grandparent
        grandparent = rotate_right(grandparent)  # Update grandparent after rotation
    else:
        if node == node.parent.left:
            # Right-left case, perform right rotation on parent
            node = rotate_right(node.parent)
            node = node.right
        # Right-right case, perform left rotation on grandparent
        grandparent = rotate_left(grandparent)  # Update grandparent after rotation

    # Recolor nodes after rotations
    node.parent.color = "black"
    node.parent.left.color = "red"
    node.parent.right.color = "red"

    return node

# Function to generate the set of characters that are considered emojis or special characters
def generate_special_chars():
    special_chars = set()
    # Add individual special characters
    special_chars.update("!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~")

    # Add emojis
    emoticons_range = range(0x1F600, 0x1F650)
    miscellaneous_range = range(0x2600, 0x27FF)
    emojis = [chr(unicode) for unicode in emoticons_range] + [chr(unicode) for unicode in miscellaneous_range]
    special_chars.update(emojis)

    return special_chars

# Function to check char is special character set or not
def is_emoji_or_special_char(char, special_chars_set):
    # Check if the character is in the set of special characters
    return char in special_chars_set

# Function to insert a keyword into the Red-Black Tree while maintaining its properties
def insert(root, keyword):
    def insert_helper(node, keyword, parent=None):
        if node is None:
            new_node = RBNode(keyword)
            new_node.parent = parent  # Set the parent of the new node
            return new_node

        if keyword < node.keyword:
            node.left = insert_helper(node.left, keyword, node)
        elif keyword > node.keyword:
            node.right = insert_helper(node.right, keyword, node)

        return node

    root = insert_helper(root, keyword)
    # Fix Red-Black Tree properties after insertion
    root = fix_insert(root)

    return root

# Function to search for a keyword in the Red-Black Tree
def search(root, keyword):
    if root is None or root.keyword == keyword:
        return root is not None

    if keyword < root.keyword:
        return search(root.left, keyword)
    else:
        return search(root.right, keyword)

# Function to build word and special character into BST tree
def build_bst_with_words_and_special_chars(words):
    key = words["keywords"]
    special = words["special"]
    root = None
    for word in key:
        root = insert(root, word)
    for char in special:
        root = insert(root, char)
    return root

# Function to calculate hit count of keyword match using BST
def count_hits_with_BST(data, keywords):
    root = build_bst_with_words_and_special_chars(keywords)
    hit_counter = 0
    for element in data:
        for keyword in keywords["keywords"]:
            if search(root, keyword) and keyword in element.lower():
                hit_counter += 1
                break
        # Perform search using the search function
        for char in element:
            if char.isdigit():
                pass
            elif is_emoji_or_special_char(char, generate_special_chars()):
                if search(root, char):
                    hit_counter += 1
    return hit_counter

# Function to set string in to array with word by word base
def arr_word_by_word(word):
    wording_array = word.split()
    output_array = []
    for word in wording_array:
        temp_word = ''
        for char in word:
            if char.isalpha() or char.isdigit():
                temp_word += char.lower()
            else:
                if temp_word:
                    output_array.append(temp_word)
                temp_word = ''
                output_array.append(char)
        if temp_word:
            output_array.append(temp_word)
    return output_array

# KMP algorithm
def compute_prefix_table(pattern):
    prefix_table = [0] * len(pattern)
    j = 0

    for i in range(1, len(pattern)):
        while j > 0 and pattern[i] != pattern[j]:
            j = prefix_table[j - 1]
        if pattern[i] == pattern[j]:
            j += 1
        prefix_table[i] = j

    return prefix_table

# KMP search method
def kmp_search(text, pattern):
    prefix_table = compute_prefix_table(pattern)
    j = 0
    hits = 0

    for i in range(len(text)):
        while j > 0 and text[i] != pattern[j]:
            j = prefix_table[j - 1]
        if text[i] == pattern[j]:
            j += 1
            if j == len(pattern):
                hits += 1
                j = prefix_table[j - 1]

    return hits

# Function to calculate hit count of keyword match
def count_hits_by_kmp(data, keywords):
    hit_counter = 0
    for element in data:
        for keyword in keywords:
            hits = kmp_search(element.lower(), keyword)
            if hits > 0:
                hit_counter += 1
                break

    return hit_counter

# Trie Node
class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False

# Trie insert
def trie_insert(root, keyword):
    node = root
    for char in keyword:
        if char not in node.children:
            node.children[char] = TrieNode()
        node = node.children[char]
    node.is_end_of_word = True

# Function to build Trie tree for keywords and symbol
def build_trie(keywords):
    key = keywords["keywords"]
    char = keywords["special"]
    trie_root = TrieNode()
    for keyword in key:
        trie_insert(trie_root, keyword)
    for special in char:
        trie_insert(trie_root, special)
    return trie_root

# Function to calculate hit count of keyword match
def count_hits_with_trie(word_array, keywords):
    trie_root = build_trie(keywords)
    hit_counter = 0
    hit_keywords = []  # List to store hit keywords

    for word in word_array:
        node = trie_root
        for char in word:
            if char in node.children:
                node = node.children[char]
                if node.is_end_of_word:
                    hit_counter += 1
                    hit_keywords.append(word)  # Add hit keyword to the list

    # hit_keywords is checking what are the keyword is been hit.
    return hit_counter, hit_keywords

# Function to get all the result
def perform_result_with_BST(text, keywords):
    combined_dict = combine_keyword_and_emoji(keywords)
    hits = count_hits_with_BST(text, combined_dict)
    # print("Total hits for keywords:", hits)
    return hits

def perform_result_with_kmp(text, keywords):
    combined_dict = combine_dict_into_one(keywords)
    hits = count_hits_by_kmp(text, combined_dict)
    # print("Total hits for keywords: "+str(hits))
    return hits

def perform_result_with_Trie(text, keywords):
    combined_dict = combine_keyword_and_emoji(keywords)
    print(combined_dict)
    hits, arr_hit_keywords = count_hits_with_trie(text, combined_dict)
    # print("Total hits for keywords:", hits)
    #print(arr_hit_keywords)
    return hits

def combine_keyword_and_emoji(loaded_dict):
    special_chars_set = generate_special_chars()
    # Combine the keywords dictionary with the special characters set into a new dictionary
    combined_dict = {
        "keywords": loaded_dict,
        "special": {char: True for char in special_chars_set}
}
    return combined_dict

def combine_dict_into_one(loaded_dict):
    special_chars_set = generate_special_chars()
    combined_dict = {**loaded_dict, **{char: True for char in special_chars_set}}
    return combined_dict

def perfomTextFunction(text, method):
    word_array = arr_word_by_word(text)
    load_keyword = load_keywords_from_csv()
    if(method == 'trie'):
        start_time = time.time()
        trie_hits = perform_result_with_Trie(word_array,load_keyword)
        end_time = time.time()
        if trie_hits > 0:
            result_text = 'There are {} word(s) which concerning. Exercise with caution. Total {} / {}'.format(trie_hits, trie_hits, len(word_array))
        else:
            result_text = 'No suspicious text was found however exercise caution if think it is a scam.'
        # Calculate the time taken and format it as seconds with two decimal places
        time_taken = "(Trie) " + "{:.4}".format((end_time - start_time) * 1000)
    elif method == 'binaryTreeSearch':
            start_time = time.time()
            bst_hits = perform_result_with_BST(word_array,load_keyword)
            end_time = time.time()
            if bst_hits > 0:
                result_text = 'There are {} word(s) which concerning. Exercise with caution. Total {} / {}'.format(bst_hits, bst_hits, len(word_array))
            else:
                result_text = 'No suspicious text was found however exercise caution if think it is a scam.'
            # Calculate the time taken and format it as seconds with two decimal places
            time_taken = "(Binary Search Tree) " + "{:.4}".format((end_time - start_time) * 1000)
    elif method == 'kmp':
        start_time = time.time()
        kmp_hits = perform_result_with_kmp(word_array,load_keyword)
        end_time = time.time()
        if kmp_hits > 0:
            result_text = 'There are {} word(s) which concerning. Exercise with caution. Total {} / {}'.format(kmp_hits, kmp_hits, len(word_array))
        else:
            result_text = 'No suspicious text was found however exercise caution if think it is a scam.'
        # Calculate the time taken and format it as seconds with two decimal places
        time_taken = "(KMP Knuth–Morris–Pratt) " + "{:.4}".format((end_time - start_time) * 1000)
        # result = perform_text_check(text)  # Invoke the backend code to perform text check
    return result_text, time_taken

def build_scam_patterns():
    scam_patterns = {
        "Generic 12-digit numbers": r"^\d{12}$",
        "Malaysian phone numbers": r"^(\+?6?01)[0-46-9]-*\d{7,8}$",
        "US phone numbers": r"^(\+?1-?)?(\()?(\d{3})(?(2)\))[-.\s]?\d{3}[-.\s]?\d{4}$",
        "Indian phone numbers": r"^(\+?91|0)?[789]\d{9}$",
        "Chinese phone numbers": r"^(\+?86-?)?1[3456789]\d{9}$",
        # Add more patterns for other high-risk Asian countries as needed
    }
    return scam_patterns

def check_scammer_number(phone_number, scammer_patterns):
    for pattern_name, pattern in scammer_patterns.items():
        if brute_force_search(phone_number, pattern):
            return True, pattern_name
    return False, None

def brute_force_search(text, pattern):
    matches = re.finditer(pattern, text)
    return any(match.group(0) == text for match in matches)

def add_scam_number(phone_number):
    try:
        # Parse the phone number to get the country information
        parsed_number = phonenumbers.parse(phone_number, None)
        country = phonenumbers.region_code_for_number(parsed_number)
    except phonenumbers.NumberParseException:
        print(f"Error: Could not parse the phone number '{phone_number}'.")
        return False

    try:
        with open('../Data/numbers.csv', 'a', newline='') as file:
            writer = csv.writer(file)
            writer.writerow([phone_number, country])
        return True
    except Exception as e:
        print(f"Error: Failed to add the phone number '{phone_number}' to the database.")
        return False




def check_scammer_number_hashmap(phone_number, scam_numbers):
    if phone_number in scam_numbers:
        return True, scam_numbers[phone_number]
    return False, None

def num_linear_search(scam_numbers, target_number):
    for number in scam_numbers:
        if number == target_number:
            return True  # Found the target number in the list, it's a scammer
    return False  # Target number not found in the list, not a scammer

def num_binary_search(arr, target):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return True  # Return True if the target is found
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return False  # Return False if the target is not found

def quick_sort(arr):
    if len(arr) <= 1:
        return arr

    pivot = arr[len(arr) // 2]
    left = [x for x in arr if x < pivot]
    middle = [x for x in arr if x == pivot]
    right = [x for x in arr if x > pivot]

    return quick_sort(left) + middle + quick_sort(right)

@app.route("/")
@app.route("/home")
def home():
    return render_template('home.html')

@app.route("/textcheck", methods=['GET', 'POST'])
def text_check():
    if request.method == 'POST':
        text = request.form.get('text')
        method = request.form.get('search_method_text')
        result_text, time_taken = perfomTextFunction(text,method)
        return render_template('textcheck.html', text=text, result=result_text,time_taken=time_taken)  # Pass All text, result and time to the template
    return render_template('textcheck.html')

@app.route("/questioncheck", methods=['GET', 'POST'])
def question_check():
    if request.method == 'POST':
        questions = loadQuestions()
        total_questions = len(questions)
        yesCount = 0
        noCount = 0

        for index, question in enumerate(questions):
            answer = request.form.get(f"question_{index}")
            if answer == 'y':
                yesCount += 1
            elif answer == 'n':
                noCount += 1

        scamPercent = yesCount / (yesCount+ noCount)

        if scamPercent <= 0.1:
            result = "Although the caller has not said anything too concerning, please exercise caution."
        elif scamPercent <= 0.5:
            result = "There is a good chance this is a scam. You should probably hang up now."
        else:
            result = "This is definitely a scam."

        return render_template('questioncheck.html', questions=questions, total_questions=total_questions, yes_count=yesCount, noCount=noCount, result=result)

    return render_template('questioncheck.html', questions=loadQuestions())

@app.route("/numbercheck", methods=['GET', 'POST'])
def number_check():
    if request.method == 'POST':
        search_method = request.form.get('search_method')

        if search_method == 'hashmap':
            start_time = time.time()
            phone_number = request.form.get('phone_number')
            scam_numbers = load_scam_numbers_from_csv()

            # Measure the time taken for hashmap search
            
            is_scammer, country = check_scammer_number_hashmap(phone_number, scam_numbers)
            end_time = time.time()

            if is_scammer:
                result = f"The number {phone_number} matches a scammer from {country}. Exercise caution!"
            else:
                result = f"The number {phone_number} does not match any known scammer."

            # Calculate the time taken and format it as seconds with two decimal places
            time_taken = "(Hashmap) " + "{:.4}".format((end_time - start_time) * 1000)

            return render_template('numbercheck.html', result=result, time_taken=time_taken, phone_number=phone_number)
        
        elif search_method == 'sortbinarysearch':
            start_time = time.time()
            phone_number = request.form.get('phone_number')
            scam_numbers = quick_sort(binary_load_scam_numbers_from_csv())    
            is_scammer = num_binary_search(scam_numbers, phone_number)
            end_time = time.time()
            if is_scammer:
                result = f"The number {phone_number} matches a scammer. Exercise caution!"
            else:
                result = f"The number {phone_number} does not match any known scammers."

            time_taken = "(Sorted Binary Search) " + "{:.4f}".format((end_time - start_time) * 1000)
            return render_template('numbercheck.html', result=result, time_taken=time_taken)
        
        elif search_method == 'linearsearch':
            start_time = time.time()
            phone_number = request.form.get('phone_number')
            scam_numbers = binary_load_scam_numbers_from_csv()

            # Check if the input phone number is a scammer using a linear search
            is_scammer = num_linear_search(scam_numbers, phone_number)

            end_time = time.time()

            if is_scammer:
                result = f"The number {phone_number} matches a scammer. Exercise caution!"
            else:
                result = f"The number {phone_number} does not match any known scammers."

            time_taken = "(Linear Search) " + "{:.4f}".format((end_time - start_time) * 1000)
            return render_template('numbercheck.html', result=result, time_taken=time_taken)

        elif search_method == 'bruteforce':
            phone_number = request.form.get('phone_number')
            scammer_patterns = build_scam_patterns()
            is_scammer, pattern_name = check_scammer_number(phone_number, scammer_patterns)

            if is_scammer:
                result = f"The number {phone_number} matches a scammer pattern: {pattern_name}. Exercise caution!"
            else:
                result = f"The number {phone_number} does not match any known scammer number."

            return render_template('numbercheck.html', result=result)

        elif 'add_scam_number' in request.form:
            scam_number = request.form['scam_number']
            if add_scam_number(scam_number):
                return redirect("/numbercheck?success=true")
            else:
                return redirect("/numbercheck?success=false")

    return render_template('numbercheck.html')

@app.route("/faq")
def faq():
    with open("../Data/faq.json") as json_file:
        faq_data = json.load(json_file)
    return render_template('faq.html', faq=faq_data)


if __name__ == '__main__':
    app.run(debug=True)
