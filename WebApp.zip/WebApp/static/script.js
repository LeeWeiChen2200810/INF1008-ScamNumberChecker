// script.js

document.addEventListener('DOMContentLoaded', function() {
    var darkModeToggle = document.getElementById('dark-mode-toggle');
    var body = document.body;
    var navbar = document.querySelector('.navbar');

    // Check if user's preference is already in dark mode
    if (localStorage.getItem('darkMode') === 'true') {
        enableDarkMode();
    }

    darkModeToggle.addEventListener('click', function() {
        if (body.classList.contains('dark-mode')) {
            disableDarkMode();
        } else {
            enableDarkMode();
        }
    });

    function enableDarkMode() {
        body.classList.add('dark-mode');
        navbar.classList.add('dark-mode'); // Apply dark mode styling to the navbar
        darkModeToggle.classList.add('btn-dark-mode'); // Add a class for styling the dark mode button
        darkModeToggle.textContent = 'Light Mode'; // Change the button text to indicate the current mode
        localStorage.setItem('darkMode', 'true');
    }

    function disableDarkMode() {
        body.classList.remove('dark-mode');
        navbar.classList.remove('dark-mode'); // Remove the dark mode styling from the navbar
        darkModeToggle.classList.remove('btn-dark-mode'); // Remove the styling class for the dark mode button
        darkModeToggle.textContent = 'Dark Mode'; // Change the button text to indicate the current mode
        localStorage.setItem('darkMode', 'false');
    }
});
